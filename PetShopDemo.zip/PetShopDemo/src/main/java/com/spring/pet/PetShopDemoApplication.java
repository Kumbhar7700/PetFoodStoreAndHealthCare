package com.spring.pet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetShopDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PetShopDemoApplication.class, args);
	}

}
